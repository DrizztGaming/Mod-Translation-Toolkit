﻿$ErrorActionPreference = "Stop"
$root = Split-Path -Parent $MyInvocation.MyCommand.Path
$main = Join-Path $root "src\RimWorld\ModTranslationToolkit.ps1"
$log = Join-Path $root "STARTUP_ERROR.log"

try {
    & $main
} catch {
    $details = @"
Mod Translation Toolkit startup error
Time: $(Get-Date -Format o)

$($_ | Out-String)

Script stack:
$($_.ScriptStackTrace)
"@
    [System.IO.File]::WriteAllText($log, $details, (New-Object System.Text.UTF8Encoding($false)))
    Write-Host $details
    Write-Host ""
    Write-Host "Saved to: $log"
    Read-Host "Press Enter to close"
}
