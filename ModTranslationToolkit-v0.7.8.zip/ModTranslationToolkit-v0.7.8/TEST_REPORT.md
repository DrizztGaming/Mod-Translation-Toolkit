# Mod Translation Toolkit v0.7.8 - LibreTranslate UTF-8 regression report

**PASS:** 19  
**FAIL:** 0

## PASS - Version 0.7.8

## PASS - LibreTranslate function located

## PASS - LibreTranslate uses raw HTTP request

## PASS - Response stream read directly

## PASS - Response collected as raw bytes

## PASS - Response explicitly decoded as UTF-8

## PASS - JSON parsed after decoding

## PASS - Fallback mojibake repair retained

## PASS - Placeholder restoration preserved

## PASS - Invoke-RestMethod removed from LibreTranslate path

## PASS - Mojibake helper still present

## PASS - PowerShell 5.1-safe UTF-8 constructor retained

## PASS - RimWorld Game CSV workflow preserved

## PASS - RimWorld Mod CSV workflow preserved

## PASS - Main XAML located

## PASS - Main XAML XML valid

## PASS - WPF Border single-child rule

## PASS - API XAML located

## PASS - API XAML XML valid
